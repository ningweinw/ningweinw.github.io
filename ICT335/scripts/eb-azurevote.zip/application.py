from flask import Flask, request, render_template
from flaskext.mysql import MySQL
import os
import random
import socket
import sys

application = Flask(__name__)

# Load configurations
application.config.from_pyfile('config_file.cfg')
button1 = application.config['VOTE1VALUE']
button2 = application.config['VOTE2VALUE']
title = application.config['TITLE'] + ' (host: ' + socket.gethostname() + ')'
dbName = 'azurevote'

# MySQL configurations
application.config['MYSQL_DATABASE_USER'] = os.environ['MYSQL_USER']
application.config['MYSQL_DATABASE_PASSWORD'] = os.environ['MYSQL_PASSWORD']
application.config['MYSQL_DATABASE_HOST'] = os.environ['MYSQL_HOST']

# MySQL Object
mysql = MySQL()
mysql.init_app(application)

# Check DB schema
print("Retrieving databases...")
connection = mysql.connect()
cursor = connection.cursor()
cursor.execute("SHOW DATABASES")
dbReady = False
for (tmpDbName,) in cursor:
    print(tmpDbName)
    if tmpDbName == dbName:
        print("Schema is ready")
        dbReady = True
        break

# Create schema if not existing
if not dbReady:
    print("Creating database...")
    cursor.execute("CREATE DATABASE " + dbName)
    print("Creating table...")
    cursor.execute("CREATE TABLE " + dbName + ".azurevote (voteid INT NOT NULL AUTO_INCREMENT, votevalue VARCHAR(45) NULL, PRIMARY KEY (voteid))")
cursor.close()
application.config['MYSQL_DATABASE_DB'] = dbName


@application.route('/', methods=['GET', 'POST'])
def index():

    # MySQL Connection
    connection = mysql.connect()
    cursor = connection.cursor()

    # Vote tracking
    vote1 = 0
    vote2 = 0

    if request.method == 'GET':

        # Get current values
        cursor.execute('''Select votevalue, count(votevalue) as count From azurevote
        group by votevalue''')
        results = cursor.fetchall()

        # Parse results
        for i in results:
            if i[0] == application.config['VOTE1VALUE']:
                vote1 = i[1]
            elif i[0] == application.config['VOTE2VALUE']:
                vote2 = i[1]

        # Return index with values
        return render_template("index.html", value1=vote1, value2=vote2, button1=button1, button2=button2, title=title)

    elif request.method == 'POST':

        if request.form['vote'] == 'reset':

            # Empty table and return results
            cursor.execute('''Delete FROM azurevote''')
            connection.commit()
            return render_template("index.html", value1=vote1, value2=vote2, button1=button1, button2=button2, title=title)
        else:

            # Insert vote result into DB
            vote = request.form['vote']
            cursor.execute(
                '''INSERT INTO azurevote (votevalue) VALUES (%s)''', (vote))
            connection.commit()

            # Get current values
            cursor.execute('''Select votevalue, count(votevalue) as count From azurevote
            group by votevalue''')
            results = cursor.fetchall()

            # Parse results
            for i in results:
                if i[0] == application.config['VOTE1VALUE']:
                    vote1 = i[1]
                elif i[0] == application.config['VOTE2VALUE']:
                    vote2 = i[1]

            # Return results
            return render_template("index.html", value1=vote1, value2=vote2, button1=button1, button2=button2, title=title)


@application.route('/results')
def results():

    # MySQL Connection
    connection = mysql.connect()
    cursor = connection.cursor()

    # Get current values
    cursor.execute('''Select * FROM azurevote''')
    rv = cursor.fetchall()
    return str(rv)


if __name__ == "__main__":
    application.run(host='0.0.0.0', debug=True, port=8080)